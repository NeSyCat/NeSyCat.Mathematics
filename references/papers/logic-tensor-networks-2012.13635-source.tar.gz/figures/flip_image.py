import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
img=mpimg.imread('mnist_eight.png')

print(img.shape)
img = np.transpose(img,(1,0,2))
plt.imshow(img)
plt.imsave("mnist_eight_transp.png",img)



